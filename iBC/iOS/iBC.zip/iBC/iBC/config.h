//
//  config.h
//  iBC
//
//  Created by Cuong Tran on 2/6/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#ifndef iBC_config_h
#define iBC_config_h

#define API_URL @"http://ws.kinectia.com/public/api/v1"
#define HASH_ALGORITHM @"HMACSHA256"
#define SECRET_KEY @"xaDEUfq6R8j3464sWrIjicaOoWsj1c17PkhWbqf6V9ygfXAjIuV4bY9DL9mFSx1"
#define KinectiaAppId @"rd4Gds"

#define ROW_HEIGHT 55

#endif
