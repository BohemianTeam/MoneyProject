//
//  AbstractNavigationController.h
//  Bars
//
//  Created by Trinh Hung on 3/17/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AbstractNavigationController : UINavigationController {
    
}
- (id) initNav;
@end
