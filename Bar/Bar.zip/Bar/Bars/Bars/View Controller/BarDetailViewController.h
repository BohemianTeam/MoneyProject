//
//  BarDetailViewController.h
//  Bars
//
//  Created by Cuong Tran on 2/25/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CoreLocationController.h"
#import "ImageCaptureViewController.h"
#import "EXF.h"
@class Bar;
@class ImageGaleryView;

@interface BarDetailViewController : UIViewController <UITableViewDelegate, UITableViewDataSource, UIImagePickerControllerDelegate, UINavigationControllerDelegate,UIActionSheetDelegate, CoreLocationControllerDelegate, UIAlertViewDelegate, ImageCaptureViewControllerDelegate>{
    UITableView                 *_tableView;
    UILabel                     *_barDescription;
    
    UIButton                    *_map;
    UIButton                    *_camera;
    UIButton                    *_upload;
    
    UIImagePickerController     *_picker;
    
    ImageGaleryView             *_galeryView;
    Bar                         *_bar;
    
    CoreLocationController      *_locationController;
    CLLocation                  *_currentLocation;
    CLLocation                  *_barLocation;
    EXFJpeg                     *_imageData;
    UIAlertView                 *_helpAlert;
    UIAlertView                 *_getLocationAlert;
}
@property (nonatomic, retain) EXFJpeg * imageData;
- (id) initWithBar:(Bar *) bar;
@end
